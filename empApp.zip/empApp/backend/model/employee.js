const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema
let Employee = new Schema({
  employee_name: {
    type: String
  },
  contact_no: {
    type: String
  },
  dob: {
    type: Date
  },
  address: {
    type: Array
  },
  gender: {
    type: String
  },
  description: {
    type: String
  },
  email: {
    type: String
  },
  city: {
    type: String
  },
  fileUpload: {
    type: String
  }
}, {
  collection: 'employee'
})

module.exports = mongoose.model('Employee', Employee)