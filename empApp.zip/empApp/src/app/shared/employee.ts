export class Employee {
  _id: String;
  employee_name: String;
  contact_no: String;
  dob: Date;
  address: String;
  gender: String;
  description: String;
  email: String;
  city: String;
  fileUpload:String;
}