import { Component } from '@angular/core';
import { Cars } from './class/cars';
import { FormControl } from '@angular/forms'; 
import { trigger, state, style, animate, transition } from '@angular/animations'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'empApp';
  /*status = false;
  switch_expression = 'one'; 
  movies: Movie[] = 
  [
    { 
      title: 'Winter Is Coming', 
      director: 'Tim Van Patten', 
      cast: 'Idris Elba,Ginnifer Goodwin, Jason Bateman', 
      releaseDate: 'March 4, 2016' 
    },
    {
      title: 'Batman v Superman: Dawn of Justice', 
      director: 'Zack Snyder', 
      cast:'Ben Affleck, Henry Cavill, Amy Adams', 
      releaseDate: 'March 25, 2016'
    },
    { 
      title: 'Captain America: Civil War', 
      director: 'Anthony Russo, Joe Russo', 
      cast: 'Scarlett Johansson, Elizabeth Olsen, Chris Evans', 
      releaseDate: 'May 6, 2016' 
    },
    {
      title: 'X-Men: Apocalypse', 
      director: 'Bryan Singer', 
      cast: 'Jennifer Lawrence, Olivia Munn, Oscar Isaac',
      releaseDate:'May 27, 2016'
    }
  ];
  cars: Cars[]=
  [
    {
    'name':'MG Hector',
    'color': 'blue'
    },
    {
    'name':'Ford',
    'color': 'olive'
    },
    {
    'name':'Kia',
    'color': 'orange'
    },
    {
    'name':'BMW',
    'color': 'red'
    },
    {
    'name':'Jaguar',
    'color': 'Green'
    },
    {
    'name':'Suzuki',
    'color': 'purple'
    }
  ]; 

  onSave($event: any){
    console.log("Save button is clicked!",$event);
  }
  onDivClick(){
    console.log("DIV is clicked!");
  }
  
  imgUrl='https://server5.kproxy.com/images/footer_left.png';

  fullName: string="";

  email = new FormControl(''); 
  updateEmail() 
  { 
    this.email.setValue('tutorial&example@example.com'); 
  } */
}

/*class Movie { 
title : string; 
director : string; 
cast : string; 
releaseDate : string; 
} */
