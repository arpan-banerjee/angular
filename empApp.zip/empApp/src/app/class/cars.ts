export class Cars {
    name: string;
    color: string;
}
