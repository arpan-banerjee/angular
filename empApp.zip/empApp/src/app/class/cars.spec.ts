import { Cars } from './cars';

describe('Cars', () => {
  it('should create an instance', () => {
    expect(new Cars()).toBeTruthy();
  });
});
