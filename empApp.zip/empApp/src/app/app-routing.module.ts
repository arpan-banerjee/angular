import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmpComponent } from './employee/add-emp/add-emp.component';
import { EditEmpComponent } from './employee/edit-emp/edit-emp.component';
import { ShowEmpComponent } from './employee/show-emp/show-emp.component';
import { AnimationComponent } from './animation/animation.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'add-emp' },
  { path: 'add-emp', component: AddEmpComponent },
  { path: 'edit-emp/:id', component: EditEmpComponent },
  { path: 'show-emp', component: ShowEmpComponent },
  { path: 'animation', component: AnimationComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
