import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddEmpComponent } from './employee/add-emp/add-emp.component';
import { EditEmpComponent } from './employee/edit-emp/edit-emp.component';
import { ShowEmpComponent } from './employee/show-emp/show-emp.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HighlightDirective } from './highlight.directive';
import { OpenCloseComponent } from './open-close/open-close.component';
import { MatToolbarModule } from  '@angular/material/toolbar';
import { MatIconModule } from  '@angular/material/icon';
import { MatSidenavModule } from  '@angular/material/sidenav';
import { MatDatepickerModule } from  '@angular/material/datepicker';
import { MatListModule } from  '@angular/material/list';
import { MatButtonModule } from  '@angular/material/button';
import { MatInputModule } from  '@angular/material/input';
import { MatCardModule } from  '@angular/material/card';
import { MatSelectModule } from  '@angular/material/select';
import { MatGridListModule } from  '@angular/material/grid-list';
import { MatNativeDateModule } from '@angular/material/core';
import { HttpClientModule } from '@angular/common/http';
import { ApiService } from './shared/api.service';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { AnimationComponent } from './animation/animation.component';
import { MatFileUploadModule } from '@angular/material/mat-file-upload';
import { FileUploadInputFor } from './fileUploadInputFor.directive';
import { MaterialFileUploadComponent } from './upload/upload.component';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';


@NgModule({
  declarations: [
    AppComponent,
    AddEmpComponent,
    EditEmpComponent,
    ShowEmpComponent,
    HighlightDirective,
    OpenCloseComponent,
    AnimationComponent,
    FileUploadInputFor,
    MaterialFileUploadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatDatepickerModule,
    MatListModule,
    MatButtonModule,
    MatInputModule,
    MatCardModule,
    MatSelectModule,
    MatGridListModule,
    MatNativeDateModule,
    HttpClientModule,
    MatTableModule,
    MatPaginatorModule,
    MatFileUploadModule,
    MatProgressBarModule,
    MatSlideToggleModule
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
