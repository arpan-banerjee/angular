import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
// import ApiService to get all student as well as section CRUD functions
import { ApiService } from './../../shared/api.service';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: 'app-edit-emp',
  templateUrl: './edit-emp.component.html',
  styleUrls: ['./edit-emp.component.css']
})
export class EditEmpComponent implements OnInit {
  employeeForm: FormGroup;
  constructor(private router: Router, public fb: FormBuilder, private actRoute: ActivatedRoute, private employeeApi: ApiService, private ngZone: NgZone) {
    var id = this.actRoute.snapshot.paramMap.get('id');
    this.employeeApi.GetEmployee(id).subscribe(data => {

      this.employeeForm = this.fb.group({
        employee_name: [data.employee_name, [Validators.required]],
        contact_no: [data.contact_no],
        dob: [data.dob],
        address: [data.address],
        gender: [data.gender],
        description: [data.description],
        city: [data.city],
        email: [data.email, [Validators.required]]
      })      
    })
   }

  ngOnInit(): void {
    
    
  }

  /* Get errors */
  public handleError = (controlName: string, errorName: string) => {
    return this.employeeForm.controls[controlName].hasError(errorName);
  }

  /* Update book */
  updateEmployeeForm() {
    console.log(this.employeeForm.value)
    var id = this.actRoute.snapshot.paramMap.get('id');
    if (window.confirm('Are you sure you want to update?')) {
      this.employeeApi.UpdateEmployee(id, this.employeeForm.value).subscribe( res => {
        this.ngZone.run(() => this.router.navigateByUrl('/show-emp'))
      });
    }
  }

}
