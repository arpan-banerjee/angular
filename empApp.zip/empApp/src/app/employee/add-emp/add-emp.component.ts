import { Component, OnInit, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from "@angular/forms";
import { ApiService } from './../../shared/api.service';


@Component({
  selector: 'app-add-emp',
  templateUrl: './add-emp.component.html',
  styleUrls: ['./add-emp.component.css']
})
export class AddEmpComponent implements OnInit {
  showDdArea = true;

  onFileComplete(data: any) {
    console.log(data);
  }

  onShowDdAreaChange(){
    console.log(this.showDdArea);
  }
  employeeForm: FormGroup;
  constructor(private router: Router, public fb: FormBuilder, private employeeApi: ApiService, private ngZone: NgZone) {
    
   }

  ngOnInit(): void {

    /*this.employeeForm = new FormGroup({
      employee_name: new FormControl(),
      contact_no: new FormControl(),
      dob: new FormControl(),
      address: new FormControl(),
      gender: new FormControl(),
      description: new FormControl()
   });*/
   this.employeeForm = this.fb.group({
    employee_name: ['', [Validators.required]],
    contact_no: [''],
    dob: [''],
    address: [''],
    gender: [''],
    description: [''],
    city: [''],
    email: ['', [Validators.required]],
    fileUpload: ['']
  })

  }

  /* Get errors */
  public handleError = (controlName: string, errorName: string) => {
    return this.employeeForm.controls[controlName].hasError(errorName);
  }  

  /* Submit book */
  submitEmployeeForm() {
    if (this.employeeForm.valid) {
      this.employeeApi.AddEmployee(this.employeeForm.value).subscribe(res => {
        this.ngZone.run(() => this.router.navigateByUrl('/show-emp'))
      });
    }
  }

}
